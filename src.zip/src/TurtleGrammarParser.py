# Generated from TurtleGrammar.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,15,71,2,0,7,0,2,1,7,1,2,2,7,2,1,0,5,0,8,8,0,10,0,12,0,11,9,0,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,
        60,8,1,1,2,1,2,5,2,64,8,2,10,2,12,2,67,9,2,1,2,1,2,1,2,0,0,3,0,2,
        4,0,0,76,0,9,1,0,0,0,2,59,1,0,0,0,4,61,1,0,0,0,6,8,3,2,1,0,7,6,1,
        0,0,0,8,11,1,0,0,0,9,7,1,0,0,0,9,10,1,0,0,0,10,1,1,0,0,0,11,9,1,
        0,0,0,12,13,5,1,0,0,13,60,5,2,0,0,14,15,5,3,0,0,15,60,5,2,0,0,16,
        17,5,4,0,0,17,18,5,5,0,0,18,19,5,14,0,0,19,20,5,6,0,0,20,60,5,2,
        0,0,21,22,5,7,0,0,22,23,5,5,0,0,23,24,5,14,0,0,24,25,5,6,0,0,25,
        60,5,2,0,0,26,27,5,4,0,0,27,28,5,5,0,0,28,29,5,14,0,0,29,30,5,8,
        0,0,30,31,5,14,0,0,31,32,5,6,0,0,32,60,5,2,0,0,33,34,5,7,0,0,34,
        35,5,5,0,0,35,36,5,4,0,0,36,37,5,5,0,0,37,38,5,14,0,0,38,39,5,6,
        0,0,39,40,5,9,0,0,40,41,5,14,0,0,41,42,5,6,0,0,42,60,5,2,0,0,43,
        44,5,7,0,0,44,45,5,5,0,0,45,46,5,4,0,0,46,47,5,5,0,0,47,48,5,14,
        0,0,48,49,5,8,0,0,49,50,5,14,0,0,50,51,5,6,0,0,51,52,5,9,0,0,52,
        53,5,14,0,0,53,54,5,6,0,0,54,60,5,2,0,0,55,56,5,10,0,0,56,57,5,14,
        0,0,57,58,5,11,0,0,58,60,3,4,2,0,59,12,1,0,0,0,59,14,1,0,0,0,59,
        16,1,0,0,0,59,21,1,0,0,0,59,26,1,0,0,0,59,33,1,0,0,0,59,43,1,0,0,
        0,59,55,1,0,0,0,60,3,1,0,0,0,61,65,5,12,0,0,62,64,3,2,1,0,63,62,
        1,0,0,0,64,67,1,0,0,0,65,63,1,0,0,0,65,66,1,0,0,0,66,68,1,0,0,0,
        67,65,1,0,0,0,68,69,5,13,0,0,69,5,1,0,0,0,3,9,59,65
    ]

class TurtleGrammarParser ( Parser ):

    grammarFileName = "TurtleGrammar.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'ENCENDER'", "';'", "'APAGAR'", "'MOVER'", 
                     "'('", "')'", "'ROTAR'", "','", "'+'", "'REPETIR'", 
                     "':'", "'{'", "'}'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "INT", "WS" ]

    RULE_program = 0
    RULE_statement = 1
    RULE_block = 2

    ruleNames =  [ "program", "statement", "block" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    INT=14
    WS=15

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(TurtleGrammarParser.StatementContext)
            else:
                return self.getTypedRuleContext(TurtleGrammarParser.StatementContext,i)


        def getRuleIndex(self):
            return TurtleGrammarParser.RULE_program

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = TurtleGrammarParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 9
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1178) != 0):
                self.state = 6
                self.statement()
                self.state = 11
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return TurtleGrammarParser.RULE_statement

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class MoverContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a TurtleGrammarParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(TurtleGrammarParser.INT)
            else:
                return self.getToken(TurtleGrammarParser.INT, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMover" ):
                return visitor.visitMover(self)
            else:
                return visitor.visitChildren(self)


    class ApagarContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a TurtleGrammarParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitApagar" ):
                return visitor.visitApagar(self)
            else:
                return visitor.visitChildren(self)


    class Rm2Context(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a TurtleGrammarParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(TurtleGrammarParser.INT)
            else:
                return self.getToken(TurtleGrammarParser.INT, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRm2" ):
                return visitor.visitRm2(self)
            else:
                return visitor.visitChildren(self)


    class Rm1Context(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a TurtleGrammarParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(TurtleGrammarParser.INT)
            else:
                return self.getToken(TurtleGrammarParser.INT, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRm1" ):
                return visitor.visitRm1(self)
            else:
                return visitor.visitChildren(self)


    class RepetirContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a TurtleGrammarParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(TurtleGrammarParser.INT, 0)
        def block(self):
            return self.getTypedRuleContext(TurtleGrammarParser.BlockContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRepetir" ):
                return visitor.visitRepetir(self)
            else:
                return visitor.visitChildren(self)


    class EncenderContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a TurtleGrammarParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEncender" ):
                return visitor.visitEncender(self)
            else:
                return visitor.visitChildren(self)


    class RotarContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a TurtleGrammarParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(TurtleGrammarParser.INT, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRotar" ):
                return visitor.visitRotar(self)
            else:
                return visitor.visitChildren(self)



    def statement(self):

        localctx = TurtleGrammarParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.state = 59
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                localctx = TurtleGrammarParser.EncenderContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 12
                self.match(TurtleGrammarParser.T__0)
                self.state = 13
                self.match(TurtleGrammarParser.T__1)
                pass

            elif la_ == 2:
                localctx = TurtleGrammarParser.ApagarContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 14
                self.match(TurtleGrammarParser.T__2)
                self.state = 15
                self.match(TurtleGrammarParser.T__1)
                pass

            elif la_ == 3:
                localctx = TurtleGrammarParser.MoverContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 16
                self.match(TurtleGrammarParser.T__3)
                self.state = 17
                self.match(TurtleGrammarParser.T__4)
                self.state = 18
                self.match(TurtleGrammarParser.INT)
                self.state = 19
                self.match(TurtleGrammarParser.T__5)
                self.state = 20
                self.match(TurtleGrammarParser.T__1)
                pass

            elif la_ == 4:
                localctx = TurtleGrammarParser.RotarContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 21
                self.match(TurtleGrammarParser.T__6)
                self.state = 22
                self.match(TurtleGrammarParser.T__4)
                self.state = 23
                self.match(TurtleGrammarParser.INT)
                self.state = 24
                self.match(TurtleGrammarParser.T__5)
                self.state = 25
                self.match(TurtleGrammarParser.T__1)
                pass

            elif la_ == 5:
                localctx = TurtleGrammarParser.MoverContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 26
                self.match(TurtleGrammarParser.T__3)
                self.state = 27
                self.match(TurtleGrammarParser.T__4)
                self.state = 28
                self.match(TurtleGrammarParser.INT)
                self.state = 29
                self.match(TurtleGrammarParser.T__7)
                self.state = 30
                self.match(TurtleGrammarParser.INT)
                self.state = 31
                self.match(TurtleGrammarParser.T__5)
                self.state = 32
                self.match(TurtleGrammarParser.T__1)
                pass

            elif la_ == 6:
                localctx = TurtleGrammarParser.Rm1Context(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 33
                self.match(TurtleGrammarParser.T__6)
                self.state = 34
                self.match(TurtleGrammarParser.T__4)
                self.state = 35
                self.match(TurtleGrammarParser.T__3)
                self.state = 36
                self.match(TurtleGrammarParser.T__4)
                self.state = 37
                self.match(TurtleGrammarParser.INT)
                self.state = 38
                self.match(TurtleGrammarParser.T__5)
                self.state = 39
                self.match(TurtleGrammarParser.T__8)
                self.state = 40
                self.match(TurtleGrammarParser.INT)
                self.state = 41
                self.match(TurtleGrammarParser.T__5)
                self.state = 42
                self.match(TurtleGrammarParser.T__1)
                pass

            elif la_ == 7:
                localctx = TurtleGrammarParser.Rm2Context(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 43
                self.match(TurtleGrammarParser.T__6)
                self.state = 44
                self.match(TurtleGrammarParser.T__4)
                self.state = 45
                self.match(TurtleGrammarParser.T__3)
                self.state = 46
                self.match(TurtleGrammarParser.T__4)
                self.state = 47
                self.match(TurtleGrammarParser.INT)
                self.state = 48
                self.match(TurtleGrammarParser.T__7)
                self.state = 49
                self.match(TurtleGrammarParser.INT)
                self.state = 50
                self.match(TurtleGrammarParser.T__5)
                self.state = 51
                self.match(TurtleGrammarParser.T__8)
                self.state = 52
                self.match(TurtleGrammarParser.INT)
                self.state = 53
                self.match(TurtleGrammarParser.T__5)
                self.state = 54
                self.match(TurtleGrammarParser.T__1)
                pass

            elif la_ == 8:
                localctx = TurtleGrammarParser.RepetirContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 55
                self.match(TurtleGrammarParser.T__9)
                self.state = 56
                self.match(TurtleGrammarParser.INT)
                self.state = 57
                self.match(TurtleGrammarParser.T__10)
                self.state = 58
                self.block()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(TurtleGrammarParser.StatementContext)
            else:
                return self.getTypedRuleContext(TurtleGrammarParser.StatementContext,i)


        def getRuleIndex(self):
            return TurtleGrammarParser.RULE_block

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlock" ):
                return visitor.visitBlock(self)
            else:
                return visitor.visitChildren(self)




    def block(self):

        localctx = TurtleGrammarParser.BlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 61
            self.match(TurtleGrammarParser.T__11)
            self.state = 65
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1178) != 0):
                self.state = 62
                self.statement()
                self.state = 67
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 68
            self.match(TurtleGrammarParser.T__12)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





