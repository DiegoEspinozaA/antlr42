import turtle
import math
from antlr4 import *
from TurtleGrammarLexer import TurtleGrammarLexer
from TurtleGrammarParser import TurtleGrammarParser
from TurtleGrammarVisitor import TurtleGrammarVisitor

class TurtleInterpreter(TurtleGrammarVisitor):
    def __init__(self):
        self.t = turtle.Turtle()
        self.lapizpinta = False
        self.angulo = 0
        self.parser = None

    def execute(self, program):
        lexer = TurtleGrammarLexer(InputStream(program))
        stream = CommonTokenStream(lexer)
        parser = TurtleGrammarParser(stream)
        tree = parser.program()
        self.visit(tree)
        print(tree.toStringTree(recog=self.parser))

    def visitEncender(self, ctx):
        self.lapizpinta = True

    def visitApagar(self, ctx):
        self.lapizpinta = False

    def visitMover(self, ctx):
        if self.lapizpinta:
                self.t.pendown()
        else:
            self.t.penup()
            
        if ctx.getChildCount() == 7:
            x = int(ctx.INT(0).getText())
            y = int(ctx.INT(1).getText())
            self.t.setheading(self.t.towards(x, y)) # Apuntar hacia (x, y)
            self.t.goto(x, y)
        
        else:
            distancia = int(ctx.INT(0).getText())
            self.t.forward(distancia)
         

    def visitRotar(self, ctx):
        angulo = int(ctx.INT().getText())
        self.t.left(angulo)
        self.angulo += angulo  # Actualiza el ángulo de orientación

    def visitRepetir(self, ctx):
            rango = int(ctx.INT().getText())
            bloque = ctx.block()
            for i in range(rango):
                self.visit(bloque)
    
    def visitRm2(self,ctx):
        x = int(ctx.INT(0).getText())
        y = int(ctx.INT(1).getText())
        angulo = int(ctx.INT(2).getText())
        self.t.setheading(self.t.towards(x, y))
        self.t.goto(x, y)
        self.t.left(angulo)
        self.angulo += angulo
    
    def visitRm1(self, ctx):
        d = int(ctx.INT(0).getText())
        self.t.forward(d)
        angulo = int(ctx.INT(1).getText())
        self.t.left(angulo)
        self.angulo += angulo
    
        
def main():
    file_name = "input.in"
    try:
        with open(file_name, 'r') as file:
            input_program = file.read()
            interpreter = TurtleInterpreter()
            interpreter.execute(input_program)
           
    except FileNotFoundError:
        print("El archivo 'input.in' no se encuentra en el directorio actual.")

    turtle.done()
    

if __name__ == "__main__":
    main()
