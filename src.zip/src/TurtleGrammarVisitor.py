# Generated from TurtleGrammar.g4 by ANTLR 4.13.1
from antlr4 import *
if "." in __name__:
    from .TurtleGrammarParser import TurtleGrammarParser
else:
    from TurtleGrammarParser import TurtleGrammarParser

# This class defines a complete generic visitor for a parse tree produced by TurtleGrammarParser.

class TurtleGrammarVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by TurtleGrammarParser#program.
    def visitProgram(self, ctx:TurtleGrammarParser.ProgramContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by TurtleGrammarParser#Encender.
    def visitEncender(self, ctx:TurtleGrammarParser.EncenderContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by TurtleGrammarParser#Apagar.
    def visitApagar(self, ctx:TurtleGrammarParser.ApagarContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by TurtleGrammarParser#Mover.
    def visitMover(self, ctx:TurtleGrammarParser.MoverContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by TurtleGrammarParser#Rotar.
    def visitRotar(self, ctx:TurtleGrammarParser.RotarContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by TurtleGrammarParser#Rm1.
    def visitRm1(self, ctx:TurtleGrammarParser.Rm1Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by TurtleGrammarParser#Rm2.
    def visitRm2(self, ctx:TurtleGrammarParser.Rm2Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by TurtleGrammarParser#Repetir.
    def visitRepetir(self, ctx:TurtleGrammarParser.RepetirContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by TurtleGrammarParser#block.
    def visitBlock(self, ctx:TurtleGrammarParser.BlockContext):
        return self.visitChildren(ctx)



del TurtleGrammarParser